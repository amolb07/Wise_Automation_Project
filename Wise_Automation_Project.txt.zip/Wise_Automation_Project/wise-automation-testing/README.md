# Wise Automation Project

## Project Overview
This project is an **Automation Testing** solution for the **Wise platform** using **Selenium WebDriver**. The automation focuses on automating the login process, navigating to the classroom, and scheduling a session using the staging environment of Wise.

The goal is to ensure the functionality of the platform by simulating real user interactions.

## Features
- **Login Automation**: Automates logging in as a tutor using phone number and OTP.
- **Classroom Navigation**: Navigates through the platform to access the classroom.
- **Session Scheduling**: Schedules a session in the classroom and verifies that it appears correctly.
- **Assertions**: Verifies key information like institute name, session details, and instructor information.

## Technologies Used
- **Selenium WebDriver**: For automating browser interactions.
- **TestNG**: For running and managing tests.
- **WebDriverManager**: To handle browser driver dependencies automatically.
- **Maven**: To manage project dependencies and build the project.

## Prerequisites
- **Java**: JDK 8 or above should be installed.
- **Maven**: To build and manage project dependencies.
- **IDE**: Eclipse or any IDE that supports Java and Maven.
- **Chrome Browser**: The script is designed to run with Google Chrome.

