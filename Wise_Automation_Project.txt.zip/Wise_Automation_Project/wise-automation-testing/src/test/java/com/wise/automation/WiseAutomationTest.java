package com.wise.automation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;

public class WiseAutomationTest {
	
	RemoteWebDriver driver;

    public static void main(String[] args) {
        // Step 1: Set up WebDriver using WebDriverManager
        
        WebDriver driver = new ChromeDriver();
        
        try {
            // Set implicit wait for general loading time
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // wait up to 10 seconds for element visibility

            // Step 2: Open Wise Staging Environment
            driver.get("https://staging-web.wise.live");
            driver.manage().window().maximize();            
            // Step 3: Log in as a tutor using the phone number and OTP
            
            
            WebElement Continue_with_Number = driver.findElement(By.xpath("//span[normalize-space()='Continue with Mobile']"));
            Continue_with_Number.click();
            WebElement phoneNumberField = driver.findElement(By.xpath("//input[@placeholder='Phone number']"));
            phoneNumberField.sendKeys("1111100000");

            WebElement otpField = driver.findElement(By.xpath("//span[normalize-space()='Get OTP']"));
            otpField.click();
            
            WebElement otpbox1 = driver.findElement(By.className("otp-field-box--0"));
            
            otpbox1.sendKeys("0");
            WebElement otpbox2 = driver.findElement(By.className("otp-field-box--1"));
            
            otpbox2.sendKeys("0");
            
            WebElement otpbox3 = driver.findElement(By.className("otp-field-box--2"));
            
            otpbox3.sendKeys("0");
            
            WebElement otpbox4 =driver.findElement(By.className("otp-field-box--3"));
            
            otpbox4.sendKeys("0");
            
            WebElement verify_button = driver.findElement(By.xpath("//span[normalize-space()='Verify']"));
            verify_button.click();
            

            

         // Wait for the institute name to be visible after login (Explicit wait)
           WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 
          //WebElement instituteName = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Testing Institute')]")));

            // Assert that the institute name is displayed
            //if (instituteName.isDisplayed()) {
              //  System.out.println("Institute name displayed.");
            //} else {
              //  System.out.println("Institute name not displayed!");
           // }

            // Step 4: Navigate to the "Group courses" and select the classroom
            WebElement groupCoursesTab = driver.findElement(By.xpath("//i[@class='v-icon notranslate mdi mdi-laptop-account theme--light']"));
            groupCoursesTab.click();
            
            WebElement classroomLink = driver.findElement(By.xpath("//a[normalize-space()='Classroom for Automated testing']"));
            classroomLink.click();

            // Wait for the classroom page to load and assert the classroom title (Explicit wait)
           // WebElement classroomTitle = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("text-center institute-info")));
            //if (classroomTitle.isDisplayed()) {
              // System.out.println("Classroom page opened successfully.");
           // } else {
            //   System.out.println("Classroom page did not open.");
           // }

             //Step 5: Navigate to "Live sessions" and schedule a new session
            WebElement liveSessionsTab = driver.findElement(By.xpath("//a[normalize-space()='Live Sessions']"));
           liveSessionsTab.click();
            
         
         
           WebElement scheduleSessionButton = driver.findElement(By.xpath("//span[normalize-space()='Schedule Sessions']"));
             scheduleSessionButton.click();
           
            WebElement addSessionButton = driver.findElement(By.xpath("//span[normalize-space()='Add session']"));
            addSessionButton.click();
            

            // Choose a time (assuming it's a time picker field) 
            WebElement timePicker = driver.findElement(By.xpath("//input[@id='input-711']"));
            timePicker.click(); // Open the time picker

            // Clear existing value using keyboard keys
            timePicker.sendKeys(Keys.CONTROL + "a"); // Select all text
            timePicker.sendKeys(Keys.BACK_SPACE); // Clear it

            // Enter new time
            timePicker.sendKeys("10:00 PM");


            WebElement createButton = driver.findElement(By.xpath("//span[normalize-space()='Create']"));
            createButton.click();
            
            // Step 6: Assert that the session is visible on the timeline
            // Wait for the session card to appear (Explicit wait)
           WebElement sessionCard = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(text(),'Upcoming session')]")));
            if (sessionCard.isDisplayed()) {
               System.out.println("Session card displayed in the timeline.");
            } else {
                System.out.println("Session card not displayed.");
            }

        } catch (Exception e) {
            System.out.println("Test failed: " + e.getMessage());
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
